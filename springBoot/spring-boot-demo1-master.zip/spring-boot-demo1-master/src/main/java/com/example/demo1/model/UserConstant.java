package com.example.demo1.model;

/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * <p>
 * Created by xiangjiangcheng on 2018/8/21 17:43.
 */
public class UserConstant {

    public final static String STATE_ACCOUNTEXPIRED = "1";

    public static final String STATE_LOCK = "1";

    public static final String STATE_TOKENEXPIRED = "1";

    public static final String STATE_NORMAL = "1";
}
