package com.example.demo1.service;

import com.example.demo1.entity.User;

import java.util.List;

/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * <p>
 * Created by xiangjiangcheng on 2018/8/20 13:48.
 */
public interface UserService {
    List<User> queryUserList();
}
